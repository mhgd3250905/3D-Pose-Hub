// Pose Studio V5 最小示例 = v3r7 画法（toon 日漫 + fx 特效 + 刺猬头）+ v3r8b 腕部修复（coach-v3r3-wristfix.glb + wristfix-r2.js + toon-r6.js）
// 加载顺序与 Pose Studio app.js / Hub tools/v5/runtime/thomas.js 相同：模型 → 重建层级 → wristfix-r2 → toon-r6（+发型）→ fx。
// 本地起服务：在本目录 `python3 -m http.server 8000`，打开 http://127.0.0.1:8000/demo.html
// 参数：?pause=1 静止 · ?f=40 停在第 40 帧 · ?wf=0 关腕部修复驱动（对照“腕口缩”的样子，辅助骨保持单位）· ?fx=0 · ?hair=mid|beanie|none · 其余同 HANDOFF/RELEASE
import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/GLTFLoader.js';
import { MeshoptDecoder } from 'three/addons/meshopt_decoder.module.js';

// 默认发型 spiky；toon-r6.js 在模块加载时读 location.search，所以必须在 import 它之前补参数
{ const q = new URLSearchParams(location.search); if (!q.has('hair')) { q.set('hair', 'spiky'); history.replaceState(null, '', location.pathname + '?' + q + location.hash); } }
const QS = new URLSearchParams(location.search);

// 22 根主骨骼（glb 里平铺，加载后重建层级）+ 每侧 8 根腕部辅助骨（ForearmTwist1..6、WristBend1..2，都挂 xxForearm 下）
const PARENT = {
  spineLower: 'pelvis', spineUpper: 'spineLower', torso: 'spineUpper', neck: 'torso', head: 'neck',
  leftScapula: 'torso', leftUpperArm: 'leftScapula', leftForearm: 'leftUpperArm', leftHand: 'leftForearm',
  rightScapula: 'torso', rightUpperArm: 'rightScapula', rightForearm: 'rightUpperArm', rightHand: 'rightForearm',
  leftThigh: 'pelvis', leftShin: 'leftThigh', leftPatella: 'leftShin', leftFoot: 'leftShin',
  rightThigh: 'pelvis', rightShin: 'rightThigh', rightPatella: 'rightShin', rightFoot: 'rightShin',
};
for (const sd of ['left', 'right']) for (let k = 1; k <= 8; k++) { PARENT[sd + 'ForearmTwist' + k] = sd + 'Forearm'; PARENT[sd + 'WristBend' + k] = sd + 'Forearm'; }

const renderer = new THREE.WebGLRenderer({ antialias: true, preserveDrawingBuffer: true });
renderer.setPixelRatio(Math.min(devicePixelRatio, 2)); renderer.outputColorSpace = THREE.SRGBColorSpace;
document.body.appendChild(renderer.domElement);
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(30, 1, 0.05, 50);
const resize = () => { renderer.setSize(innerWidth, innerHeight, false); camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix(); };
addEventListener('resize', resize); resize();
scene.add(new THREE.HemisphereLight(0xffffff, 0x8890a0, 1.6));
const floor = new THREE.Mesh(new THREE.CircleGeometry(2, 48).rotateX(-Math.PI / 2), new THREE.MeshBasicMaterial({ color: 0xdfe3ea }));
scene.add(floor);

const [gltf, anim] = await Promise.all([
  new GLTFLoader().setMeshoptDecoder(MeshoptDecoder).loadAsync('./model/coach-v3r3-wristfix.glb'),
  fetch('./anim/flare-arm8legs-v3r3.json').then(r => r.json()),
]);
const root = gltf.scene; scene.add(root); root.updateMatrixWorld(true);
const bones = {}, skinned = [];
root.traverse(o => { if (o.isBone) bones[o.name] = o; if (o.isSkinnedMesh) { skinned.push(o); o.frustumCulled = false; } });
for (const [c, p] of Object.entries(PARENT)) if (bones[c] && bones[p]) bones[p].attach(bones[c]);   // attach 保持世界变换
root.updateMatrixWorld(true);
for (const b of Object.values(bones)) b.quaternion.identity();          // 静止姿势：所有局部旋转 = 单位

// 腕部修复：包一层 renderer.render，每次渲染前按手相对前臂的旋转驱动 16 根辅助骨（手骨本身不动）。必须在 toon/fx 之前装。
const wfOn = QS.get('wf') !== '0';
const wf = wfOn ? (await import('./src/wristfix-r2.js')).installWristFix({ bones, renderer }) : null;

// 日漫皮肤 + 发型（toon-r6 = toon-r5 + 腕弯辅助骨折算描边粗细；按「相对页面」的 ./model/hair-v3r5.glb 加载发型）
const { applyToon } = await import('./src/toon-r6.js');
const toon = applyToon({ scene, root, bones, skinned, grid: null, floor, renderer, camera });
if (toon.hairReady) await toon.hairReady.catch(e => console.error('hair failed', e));

const JOINTS = Object.keys(anim.frames[0].q);
let frame = +(QS.get('f') || 0);
const setFrame = f => { const fr = anim.frames[f]; for (const id of JOINTS) if (bones[id]) bones[id].quaternion.fromArray(fr.q[id]).normalize(); bones.pelvis.position.fromArray(fr.p); };
setFrame(frame);

if (QS.get('fx') !== '0') { const { applyFx } = await import('./src/fx.js'); window.__fxInfo = applyFx({ scene, root, bones, skinned, renderer, anim, getFrame: () => frame, getFrames: () => anim.frames, jointIds: JOINTS }); }

const cam = anim.cams.v0; camera.position.fromArray(cam.p); camera.lookAt(new THREE.Vector3().fromArray(cam.t)); camera.fov = cam.f; camera.updateProjectionMatrix();
const fps = anim.fps; let t0 = performance.now(), paused = QS.has('pause') || QS.has('f');
const HELPERS = Object.keys(bones).filter(n => /ForearmTwist\d|WristBend\d/.test(n));
window.__demo = {
  ready: true, wristfix: !!wf, helpers: HELPERS, toon: { hair: toon.hair, outlines: toon.outlines },
  goFrame(f) { paused = true; frame = f; setFrame(f); renderer.render(scene, camera); },
  snap() { return renderer.domElement.toDataURL('image/png'); },
  // 烘焙用：按播放顺序逐帧驱动，返回每帧 16 根辅助骨的局部四元数（父 = xxForearm），可直接写进 AnimationClip 轨道
  bakeWrist() { if (!wf) return null; const out = []; for (let f = 0; f < anim.count; f++) { setFrame(f); wf.update(); const q = {}; for (const n of HELPERS) q[n] = bones[n].quaternion.toArray().map(v => +v.toFixed(7)); out.push(q); } return out; },
};
renderer.setAnimationLoop(now => {
  if (!paused) { frame = Math.floor(((now - t0) / 1000 * fps * 0.5) % anim.count); setFrame(frame); }   // 0.5× 速，整帧切换（与网页一致，不插值）
  renderer.render(scene, camera);
});
