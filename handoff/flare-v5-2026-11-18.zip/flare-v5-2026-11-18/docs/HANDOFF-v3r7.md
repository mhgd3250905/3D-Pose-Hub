# Flare 托马斯全旋 · Pose Studio v3r7 建模交付包

- 交付日期：2026-11-16（CST）。来源：Pose Studio v3r7 定版（线上 https://pose.uuugk.win ，生产部署 dda405b3），开哥 2026-11-16 00:01 同意「把这个建模给托马斯那边用」。
- 本包只是资源与说明，**没有改动 Flare 3D-Body 仓库**。接入、合并、发版需开哥另行同意。
- 校验：包内 `MD5SUMS`（`md5sum -c MD5SUMS`）。

## 1. 包内文件

| 路径 | 内容 |
|---|---|
| `model/coach-v3r3.glb` | 人体模型 v3r3（22 骨，单层身体，皮肤/上衣/裤/袜/鞋分材质 + `_REGION` 顶点属性，无名指/小指伸直），1.83 MB |
| `model/hair-v3r5.glb` | 发型 3 款：节点 `hair_spiky`、`hair_mid`、`hair_beanie`，几何是 head 骨骼局部坐标，0.47 MB |
| `anim/flare-arm8legs-v3r3.json` | **托马斯全旋动画（配 v3r3 用）**：162 帧 @120 fps，双腿伸直版（flare-arm8 手臂优化 + 膝全程伸直） |
| `anim/flare-arm8legs.json` | 同一动作的 r17 骨架版（骨盆位置按 r17 模型对齐），给 r17 模型用；v3r3 请用上一个 |
| `src/toon-r5.js` | 日漫三渲二皮肤：粗色线描边、两阶平涂、脸、发型、配色 |
| `src/fx.js` | 日漫特效：荧光火焰脚尖拖尾、星点、撑地圈、硬边地面投影 |
| `vendor/` | three.js r170：`three.module.min.js`，`addons/GLTFLoader.js`、`addons/meshopt_decoder.module.js`、`addons/BufferGeometryUtils.js`（GLTFLoader 依赖） |
| `demo.html` + `demo.js` | 最小可跑示例（无编辑器 UI），流程与线上 app.js 相同 |
| `preview/fx4-cmp.png`、`preview/fx4-demo.mp4` | 效果对比图与演示视频（r4，即定稿画法） |

跑示例：在包根目录 `python3 -m http.server 8000`，打开 `http://127.0.0.1:8000/demo.html`（`?pause=1` 静止、`?hair=mid`、`?fx=0` 等参数见第 5 节）。沙箱无头浏览器实测报错 0。

## 2. 环境要求
- **three.js 0.170.0（r170）**。3D-Body `app/scene/package.json` 也是 `three: 0.170.0`，版本一致。
- ES module + importmap（或打包器）解析 `three`、`three/addons/`。toon-r5.js 用到 `three/addons/GLTFLoader.js`。
- 模型用了 `EXT_meshopt_compression` + `KHR_mesh_quantization`：`GLTFLoader` 必须 `setMeshoptDecoder(MeshoptDecoder)`。hair-v3r5.glb 没压缩。
- 渲染器：`outputColorSpace = SRGBColorSpace`；toon 与 fx 都是自定义 ShaderMaterial，不依赖场景灯光。

## 3. 坐标与骨骼约定
- 单位米，**Y 向上，人物面朝 +Z，+X 是人物的左侧**。静止姿势 = T 字站姿。
- 22 根骨骼：`pelvis spineLower spineUpper torso neck head`、`left/right` + `Scapula UpperArm Forearm Hand Thigh Shin Patella Foot`。没有手指骨（手指形状在网格里）。
- **glb 里骨骼是平铺的**（都在场景根下，节点平移 = 世界位置，旋转 = 单位）。加载后必须按下表重建父子关系（`parent.attach(child)` 保持世界变换），再把所有骨骼局部旋转设为单位：

```
spineLower←pelvis  spineUpper←spineLower  torso←spineUpper  neck←torso  head←neck
left/rightScapula←torso  *UpperArm←*Scapula  *Forearm←*UpperArm  *Hand←*Forearm
left/rightThigh←pelvis  *Shin←*Thigh  *Patella←*Shin  *Foot←*Shin
```
- 动画 JSON：`{id, name, model, fps:120, count:162, cams:{v0,v1}, phases:[{n,f}], frames:[{q,p,lock,a}]}`
  - `q`：20 根骨骼（不含 Patella）在**上面重建后的层级**里的局部四元数 `[x,y,z,w]`，相对 T 姿。
  - `p`：pelvis 的位置（米，场景根坐标）。
  - `lock`：`[左手撑地, 右手撑地]`（0/1），fx.js 不用它（撑地圈按掌心高度自己判断），可用于教学阶段。
  - `a`：视频解算的左肘、右肘、左膝、右膝角（度）。
  - `cams.v0`：渲染视频机位 `{p, t, f}`；`phases`：关键阶段帧号。
- 线上网页播放是**整帧切换、不插值**。

## 4. 加载流程（对照 demo.js）
1. `GLTFLoader + MeshoptDecoder` 加载 `coach-v3r3.glb`，收集 `bones[name]` 与 `skinned[]`（`frustumCulled=false`）。
2. 按第 3 节重建层级，`quaternion.identity()`。
3. `applyToon({ scene, root, bones, skinned, grid, floor, renderer, camera })`（toon-r5.js），`await toon.hairReady`。
   - 副作用：`scene.background = #f4efe6`；`grid` 移除；`floor` 换成米色半透明材质；身体换 toon 材质；加描边外壳（`userData.__outline`）；脸部豆豆眼、眉挂到 head；按 URL `hair=` 加载发型挂到 head。
   - **发型路径写死为相对页面的 `./model/hair-v3r5.glb`**（toon-r5.js 第 481 行）。放到别处要改这一行。
   - 不用 toon-r5 也能挂发型：加载 hair-v3r5.glb，取 `hair_spiky` 等节点，`bones.head.add(node)`（单位变换，刚性跟头），自己给材质。
4. 每帧：`bones[id].quaternion.fromArray(frame.q[id])`，`bones.pelvis.position.fromArray(frame.p)`。
5. `applyFx({ scene, root, bones, skinned, renderer, anim, getFrame, getFrames, jointIds, params })`（fx.js）：
   - `getFrame()` 返回当前帧号，`null` 时特效隐藏；`getFrames()` 返回帧数组（编辑后的帧换了数组会自动重算）；`jointIds` = 要驱动的骨骼名（用 `Object.keys(frames[0].q)`）。
   - 初始化时会把骨骼摆遍全部帧做预计算，结束后恢复原姿势；挂在 `scene.onBeforeRender`（会串上原有回调）。
   - 时间换算 `wall = frame / fps`。网页只传整数帧；传小数帧做插值播放**按代码推断可行，未实测**。
   - 参数可用 `params` 对象覆盖（键见 `export const FX_PARAMS`），不必走 URL。

## 5. 参数
toon-r5.js 和 fx.js 在**模块加载时读 `location.search`**。嵌进 Flare 时，要么页面 URL 带参数，要么改成从选项传入（建议接入时做这一步，本包未改）。

| 参数 | 默认 | 作用 |
|---|---|---|
| `hair` | `none`（线上与 demo 自动补 `spiky`） | `spiky` / `mid` / `beanie` / `none` |
| `outfit` | `default` | `default` 蓝上衣深蓝裤白鞋 / `mono` / `redblack` |
| `cap` / `hairc` | 红 / `black` | 毛线帽颜色（6 位 hex）/ 发色 `black`、`brown` |
| `ol` | 开 | `ol=0` 回旧细描边与旧明暗 |
| `rim` | 关 | `rim=1` 找回带逆光边的三阶明暗（对照用） |
| `tsm` | 48 | 明暗平滑法线扩散次数（0 关；加载时约 0.8 s，swiftshader） |
| `olw` / `olk` / `olpush` | 0.0048 / 0.5 / 0.012 | 描边粗细 / 随距离变化程度 / 外壳后推（米） |
| `fx` | 开 | demo 里 `fx=0` 不加载 fx.js（线上同） |
| `fxglow` / `fxwide` / `fxflick` / `fxcore` | 1 / 1.6 / 1 / 1 | 拖尾强度 / 宽度倍数 / 摇曳 / 白芯 |
| `fxshadow` / `fxring` / `fxspark` | 开 | `=0` 单项关闭投影 / 撑地圈 / 星点 |
| `fxcell` | 0.022 | 投影网格降采样格子（米） |
| `fxold` | 关 | `=1` 旧 3D-Body 加色画法（同轨迹，对照用） |

## 6. 性能（沙箱 swiftshader 软件渲染，只作相对参考，真机未测）
- 600×600 单帧渲染中位数：v3r7 默认 370.5 ms；不带特效 361.9 ms；v3r6b（无特效、旧描边）356.7 ms。
- 网页就绪：v3r7 默认中位数 8.8 s，v3r6b 6.0 s。多出的时间主要是平滑法线（约 0.8 s）和特效预计算/投影网格。
- 模型 135,136 顶点 / 263,299 三角形；发型 spiky 7,812 / mid 7,776 / beanie 2,988 三角形。

## 7. 与 3D-Body 现有代码的对应（按本地 2026-10 归档快照 `archive/2026-10/work/flare/3D-Body`，最后提交 7eaccf7 推断；接入前请以仓库最新 main 为准）

| 本包 | 3D-Body | 关系 / 差异 |
|---|---|---|
| `src/fx.js` `applyFx()` | `app/scene/src/fx.js` `createFlareFx(player, {palette, enabled})`，在 `main.js` 第 243 行创建 | 本包轨迹逻辑就是从它 1:1 移植的：脚尖取点规则、720 样本、0.95 s 拖尾 × 圈时长/8.9917 s、56 段、18 星点 0.8 s、撑地圈 0.9 s 最多 4 个。不同：①输入是逐帧 JSON + 帧号，不是 AnimationClip + 连续时间；②画法改成日漫荧光火焰（`?fxold=1` 可看原加色画法）；③多了硬边地面投影；④暂停/选中/详情时 3D-Body 会淡出，本包只在帧号为 null 时隐藏，没有淡出 |
| `model/coach-v3r3.glb` + `anim/*.json` | `characters.js` 的 `BASES`（`flare-coach-v42-r17-*.meshopt.glb.gz`）+ `baked-motion.js` `createBakedMotion()`（要求 glb 内含 22 骨、44 轨的 clip `flare_v42_candidate_loop`，用 AnimationMixer 播放） | 本包模型**不含动画**，动作在 JSON 里。接进 baked-motion 需要先把 JSON 烘成 44 轨 clip（22 骨 × 位置 + 四元数，按第 3 节层级）写进 glb，或另写一条逐帧驱动的播放路径。骨名是否与 v42 rig 完全一致未核对 |
| `src/toon-r5.js` `applyToon()` | `characters.js` `applyCharacter(model, character)`（只换材质 + 刚性头饰，`?character=`） | 思路相同（不改骨骼和动作，只换材质、加头饰）。toon-r5 额外加描边外壳、脸部、改背景和地面，并按 `_REGION`/材质名分区，依赖 v3r3 模型的分区，不能直接套在 v42 模型上 |
| fx 开关 | Flutter bridge 命令 `{type:'fx', value}`、`?fx=0` | 本包同样认 `?fx=0`，没有运行时开关；要接 bridge 需在 applyFx 返回的 `info.group` 上切 `visible` |

**建议接入点**（只是建议，未动仓库）：新增一个 character/base（如 `toon-v3r3`）走独立加载分支：加载本包模型 → 重建层级 → applyToon → 逐帧驱动（或先烘 clip 进 glb 再走 `createBakedMotion`）→ 用本包 fx.js 替换或并列现有 `createFlareFx`，`getFrame` 由 `player.time` 换算帧号。

## 8. 已知瑕疵
- 加载比旧版慢约 2.8 s（swiftshader）；真机未测。
- 脚仍是勾脚（全程接近中立位）；支撑手掌根最低点 −2.86 mm（略低于地面）；右臂约第 155 帧有角速度尖峰；beanie 帽檐明暗交界有一道细线；腋窝挤扁处有隐藏三角形。
- 腿朝镜头甩的少数帧，拖尾可能在腿上留淡亮条（r1 记录，定稿画法下截图目测未见明显问题）。
- toon-r5.js / fx.js 文件头注释有过时描述（写着「墨线」「同 toon-r4」），以本说明为准。
