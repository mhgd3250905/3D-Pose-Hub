# V5 建模（冻结，2026-11-18 CST）

V5 = **v3r7 画法** + **v3r8b 腕部修复**。开哥 2026-11-18 11:00 要求做版本管理，并交给 hark-mhgd 推进到 Flare App。
本目录是冻结副本：**不要就地改**，改动另建版本目录。未部署 pose.uuugk.win（线上仍是 v3r7-final）。校验：`md5sum -c MD5SUMS`。

## 组成
| 路径 | 内容 | 来源 / md5 |
|---|---|---|
| `model/coach-v3r3-wristfix.glb` | v3r3 人体 + 每侧 8 根腕部辅助骨（ForearmTwist1..6、WristBend1..2，挂 xxForearm）+ 腕缝 9 顶点/侧收进手臂网格；手骨/手掌/手指权重与 v3r3 相同 | v3r8b 候选 = Hub tools/v5/runtime/model，68dcdd98 |
| `model/hair-v3r5.glb` | 发型 spiky/mid/beanie（V5 托马斯用 spiky） | v3r7-final，15132e8a |
| `src/wristfix-r2.js` | 腕辅助骨运行时驱动（render 前把手相对前臂的旋转拆成扭转+摆动分给辅助骨；手骨不动） | v3r8b，70debbb0 |
| `src/toon-r6.js` | 日漫两阶平涂 + 粗色线描边（= toon-r5 + 腕弯辅助骨折算描边粗细，描边与 r5 逐顶点一致） | v3r8b，70263629 |
| `src/fx.js` | 荧光火焰脚尖拖尾、星点、撑地圈、硬边投影（只用于托马斯） | v3r7-final 原样，d0ccc9f1 |
| `anim/flare-arm8legs-v3r3.json` | 托马斯全旋双腿伸直版，162 帧 @120 fps | v3r7-final 原样，974ce261 |
| `anim/flare-arm8legs-v3r3.wrist-helpers.json` | **新增**：上面动画逐帧 16 根腕辅助骨局部四元数（wristfix-r2 导出），供烘进 clip | 本版生成 |
| `vendor/` | three.js r170（three.module.min.js、addons GLTFLoader / meshopt_decoder / BufferGeometryUtils） | 同 v3r7 交付包 |
| `demo.html` + `demo.js` | 最小示例：托马斯 + 刺猬头 + fx + 腕修复；`?wf=0` 关腕修复对照，`?f=N` 停帧 | 本版新写（加载顺序同 app.js / Hub thomas.js） |
| `preview/` | 渲染机 V5 托马斯预览图（qa/v5-render-1117 thomas.jpg）、沙箱同命令成片浅色 mp4、V5 vs v3r7 对照图 | — |

## 与 v3r7 的差异
- 模型 coach-v3r3.glb → coach-v3r3-wristfix.glb（+16 辅助骨、补腕缝）；toon-r5 → toon-r6；新增 wristfix-r2.js。其余（画法、配色、发型、fx、托马斯动画）逐字节相同。
- 效果：腕口最大周长缩减 33% → ≈1.4%（hub 动作）/ 托马斯 10.6% → 1.1%；腕缝细线消失；手/脚世界位置差 0（撑地落点不变，分享码不变）。
- Hub 侧：用 V5 模型时 wrist-twist twistShare = 0（wristfix-r2 也会自动撤回 hub 那层，防叠加）。

## 对应
- 3D-Pose-Hub 分支 `codex/v5-toon-render` @ **659cc7a**（Draft PR #44）；运行时拷贝 `tools/v5/runtime/`（md5 与本目录一致），托马斯渲染 `tools/v5/thomas/render-thomas.mjs`。
- 托马斯成片（渲染机）：`F:\PoseHub-v3\runs\2026-11-17_v5r2_40105eb\packages\thomas-flare-arm8legs\`（v5-toon：透明 webm、深/浅 mp4 720²，30fps，81 帧 = 2.7 s 一圈，封面/缩略图/关键帧）；预览 https://github.com/mhgd3250905/3D-Pose-Hub/blob/qa/v5-render-1117/thomas.jpg
- 训练动作（249 个，光头、无特效）同一 V5 皮肤目录 v5-toon，另行发 pack。
- 回滚点：v3r7-final（`versions/v3r7-final-2026-11-16/`，交付包 `handoff/flare-v3r7-2026-11-16/`）。
- Flare 交付包：`handoff/flare-v5-2026-11-18/`（+zip）。

## 验证（沙箱 swiftshader，2026-11-18）
- demo.html 默认 / `?wf=0` 两种都报错 0，就绪约 9.4 s；toon 描边 8、spiky、fx 开、辅助骨 16。抽帧 0/40/80/120 截图见 `/workspace/work/v5-handoff-1118/out/sheet.png`。
- wrist-helpers 导出 162 帧，辅助骨最大局部旋转 56.4°，逐帧最大跳变 6.1°（含循环接缝）。
