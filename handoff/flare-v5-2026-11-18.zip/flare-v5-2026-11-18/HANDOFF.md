# Flare 托马斯全旋 · V5 建模交付包（2026-11-18 CST）

- V5 = Pose Studio **v3r7 画法**（日漫两阶平涂 + 粗色线描边、fx 特效、刺猬头 spiky、双腿伸直托马斯 flare-arm8legs）+ **v3r8b 腕部修复**（腕口不再"缩一下"）。
- 开哥 2026-11-18 11:00：做版本管理，交 hark-mhgd 把新建模推进到 Flare App，出测试包给开哥看效果。
- 本包只是资源与说明，**没有改 Flare 仓库**。合并、上架、对外发布只认开哥本人。
- 冻结源：`/workspace/work/versions/v5-2026-11-18/`（Hark 沙箱）。校验：包内 `md5sum -c MD5SUMS`。
- 坐标、骨骼层级、动画 JSON 字段、toon/fx 参数、与 3D-Body 代码的对应：见 `docs/HANDOFF-v3r7.md`（全部仍适用，下文只写 V5 的不同）。

## 1. 与 v3r7 包（flare-v3r7-2026-11-16）的差异
| | v3r7 包 | V5 包 |
|---|---|---|
| 模型 | `coach-v3r3.glb`（22 骨） | `model/coach-v3r3-wristfix.glb`：22 骨 + 每侧 8 根辅助骨 `left/rightForearmTwist1..6`、`left/rightWristBend1..2`（父骨都是同侧 `xxForearm`）；腕缝补齐。手骨、手掌、手指、其它部位权重不变 |
| 腕驱动 | 无 | `src/wristfix-r2.js`（新增）：`installWristFix({bones, renderer})`，包住 `renderer.render`，每次渲染前驱动 16 根辅助骨；**手骨本身不动**，撑地落点不变 |
| 皮肤 | `src/toon-r5.js` | `src/toon-r6.js`（= r5 + 腕弯辅助骨折算描边粗细；画面与 r5 相同） |
| 动画 | arm8legs v3r3 + r17 两份 | 只留 `anim/flare-arm8legs-v3r3.json`（与 v3r7 逐字节相同）+ 新增 `anim/flare-arm8legs-v3r3.wrist-helpers.json`（逐帧 16 根辅助骨四元数，烘 clip 用） |
| fx / 发型 / vendor | — | 不变（fx.js d0ccc9f1、hair-v3r5.glb、three r170） |
| demo | demo.html | demo.html 换 V5 加载顺序；`?wf=0` 关腕修复对照，`?f=N` 停帧，`?pause=1` |
| 预览 | fx4 图/视频 | `preview/thomas-v5-render-machine.jpg`（渲染机成片预览）、`thomas-v5-sandbox-light.720.mp4`（沙箱同命令出的浅色成片）、`thomas-v5-vs-v3r7.png` |

效果：腕口最大周长缩减 托马斯 10.6% → 1.1%（hub 训练动作 33% → ≈1.4%），腕部细线消失。

跑示例：包根目录 `python3 -m http.server 8000` → `http://127.0.0.1:8000/demo.html`。沙箱 swiftshader 实测报错 0，就绪约 9.4 s。

## 2. 两种接入方式
### A. 直接用渲染机上的 V5 托马斯成片（最快，推荐先出测试包）
- 路径：`F:\PoseHub-v3\runs\2026-11-17_v5r2_40105eb\packages\thomas-flare-arm8legs\`（`v5-toon/`：`loop.alpha.720.webm` 透明 vp9、`light/` `dark/` 下 `loop.720.mp4`、封面/缩略图/start·peak·end 关键帧；`package.json`）。
- 规格：720²，30 fps，81 帧 = 2.7 s 一圈（= 网页默认 0.5× 速），首尾无缝循环；刺猬头 + 火焰拖尾/星点/撑地圈 + 半透明投影已画进片里。
- 预览：https://github.com/mhgd3250905/3D-Pose-Hub/blob/qa/v5-render-1117/thomas.jpg ；渲染工具 3D-Pose-Hub `codex/v5-toon-render` @659cc7a（Draft PR #44）`tools/v5/thomas/render-thomas.mjs`。
- 代价：不能转视角、不能逐帧交互；App 里若有暂停/选中淡出特效等交互，需要用视频帧替代。

### B. 实时 3D 接入（3D-Body 现在是 baked 44 轨 clip + AnimationMixer）
1. 加载 `coach-v3r3-wristfix.glb`（MeshoptDecoder），按 `docs/HANDOFF-v3r7.md` 第 3 节重建 22 骨层级，**再把 16 根辅助骨 attach 到同侧 xxForearm**（见 demo.js 的 PARENT），全部局部旋转置单位。
2. 腕辅助骨必须有人驱动，二选一（不驱动 = 腕口照旧缩，等于没修）：
   - **运行时驱动**：`installWristFix({bones, renderer})`，要在 toon / fx 之前装；每帧照常设主骨四元数即可。
   - **烘进 clip**：主骨轨道照旧（20 骨来自 `flare-arm8legs-v3r3.json`），再加 16 根辅助骨的四元数轨道，值取 `flare-arm8legs-v3r3.wrist-helpers.json` 的 `frames[f][i]`（顺序见 `bones`，父骨 = xxForearm，`[x,y,z,w]`，120 fps，162 帧）。烘进去后**不要再装 wristfix-r2**（会重复驱动）。clip 轨道数从 44 增至 44 + 16。
   - 帧间若插值，辅助骨四元数用 slerp；逐帧跳变最大 6.1°，插值安全。其它动画想用 V5 模型，要么运行时驱动，要么用 demo 的 `__demo.bakeWrist()` 同法导出。
3. 皮肤用 `toon-r6.js`（不是 r5，r5 在 wristfix 模型上腕部描边粗细会偏）；发型路径写死 `./model/hair-v3r5.glb`（toon-r6 第 483 行）。fx 用 `src/fx.js`，`getFrame` 由 `player.time` 换算帧号。
4. toon-r6 / fx 在模块加载时读 `location.search`，嵌进 App 时注意（详见 v3r7 说明第 5 节）。
5. 3D-Body 的 v42 rig 骨名与本模型是否一致未核对；接入前以 Flare 仓库最新 main 为准。

## 3. 验收要点（出测试包给开哥前自查）
- **腕口不缩**：整圈逐帧看，尤其撑地帧和手腕大角度翻转的帧，前臂到手腕粗细连续，无"捏一下"、无腕部细线；可对照 demo `?wf=0`。
- **刺猬头**：spiky 发型跟头走，360° 无露馅、无穿模。
- **特效**：脚尖荧光火焰拖尾（淡、不实质化）、星点、撑地圈都在，循环接缝处不跳。
- **投影**：硬边两阶地面投影跟随身体；成片里是半透明暖黑，深色背景下不发亮。
- 画风：纯 2D 三渲二，身体无轮廓光/逆光边；撑地手位置与 v3r7 一致；手机真机帧率与加载时长记一下（沙箱只测过软件渲染）。

## 4. 已知
- 真机性能未测；加载比旧 r17 版慢约 3 s（swiftshader）。
- 脚仍是勾脚（开哥定的不改）；右臂约第 155 帧角速度尖峰；腿朝镜头甩的少数帧拖尾可能在腿上留淡亮条（v3r7 起就有）。
- wrist-helpers.json 与运行时驱动同源导出，未做逐像素比对。
